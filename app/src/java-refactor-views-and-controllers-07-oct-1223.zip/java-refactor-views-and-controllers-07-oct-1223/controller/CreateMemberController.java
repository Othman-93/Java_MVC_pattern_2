package controller;

import java.util.Optional;
import java.util.Scanner;

import model.Email;
import model.LendingSystem;
import model.Member;
import model.Name;
import model.PhoneNumber;
import view.CreateMemberView;

public class CreateMemberController {

    protected void createMember(CreateMemberView view, LendingSystem ls, Scanner scanner) {

        Optional<Member> optionalMember = view.createMember(ls.getCurrentDay(), scanner);

        if (!optionalMember.isPresent()) {
            view.printAbortMessage();
            return;
        }

        try {
            Member viewMember = optionalMember.get();

            Member newMember = new Member(
                new Name(viewMember.getName()),
                new Email(viewMember.getEmail()),
                new PhoneNumber(viewMember.getPhoneNumber()),
                ls.getCurrentDay());

            ls.addMember(newMember);
        } catch (Exception e) {
            view.printError(e.getMessage());
        }
    } 
}
