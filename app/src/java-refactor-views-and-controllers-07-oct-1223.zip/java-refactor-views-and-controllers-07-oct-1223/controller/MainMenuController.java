package controller;

import java.util.Scanner;
import model.Email;
import model.LendingSystem;
import model.Member;
import model.Name;
import model.PhoneNumber;
import view.CreateMemberView;
import view.ListMembersView;
import view.MainMenuView;

/**
 * MainMenuController class.
 */
public class MainMenuController {

  private Scanner scanner;
  private model.LendingSystem ls;

  /**
   * Constructor.
   */
  public MainMenuController() {
    this.ls = new LendingSystem();
    this.scanner = new Scanner(System.in, "UTF-8");

    setUp();
  }

  /**
   * The start of the application will display system info and the main menu.
   */
  public void start() {

    //These should be added through dependency injection?
    CreateMemberView createMemberView = new CreateMemberView();
    CreateMemberController createMemberController = new CreateMemberController();
    ListMembersView listMembersView = new ListMembersView();
    ListMembersController listMembersController = new ListMembersController();

    MainMenuView.Action action;
    MainMenuView mainMenu = new MainMenuView();

    do {
      int memberCount = ls.getTotalNumberOfMembers();
      int itemCount = ls.getTotalNumberOfItems();
      int contractCount = ls.getTotalNumberOfContracts();
      int activeContractCount = ls.getTotalNumberOfActiveContracts();
      mainMenu.displaySysteminfo(memberCount, itemCount, activeContractCount, contractCount);

      int day = ls.getCurrentDay();
      mainMenu.displayMenu(day);

      action = mainMenu.getUserAction(scanner);

       switch (action) {
        case CREATE_MEMBER:
          createMemberController.createMember(createMemberView, ls, scanner);
          break;
        case LIST_MEMBERS:
          listMembersController.listMembers(listMembersView, ls, scanner);
          break;
        case LIST_MEMBERS_VERBOSE:
          //listMembersVerbose();
          break;
        case ADVANCE_DAY:
          ls.advanceDay();
          break;
        case EXIT:
          scanner.close();
          break;
        case None:
          break;
        default:
          break;
      }

    } while (action != MainMenuView.Action.EXIT);
  }

  private void setUp() {
    Member member1 = new Member(new Name("Othman"), new Email("Othman@email.com"), new PhoneNumber("123"),
        ls.getCurrentDay());

    member1.addItem("PS5", "The best gaming console", "Gaming", 10, ls.getCurrentDay());

    member1.addItem("Electric bike", "Easy workout Bike", "cycleling", 50, ls.getCurrentDay());

    ls.addMember(member1);
    member1.addCredits(200);

    Member member2 = new Member(new Name("Tobias"), new Email("Tobias@email.com"), new PhoneNumber("12223"),
        ls.getCurrentDay());
    ls.addMember(member2);

    Member member3 = new Member(new Name("Harry"), new Email("Harry@email.com"), new PhoneNumber("12344"),
        ls.getCurrentDay());
    ls.addMember(member3);
  }
}