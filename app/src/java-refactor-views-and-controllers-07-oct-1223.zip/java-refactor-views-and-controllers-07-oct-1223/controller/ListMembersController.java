package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import model.Contract;
import model.Email;
import model.Item;
import model.LendingSystem;
import model.Member;
import model.Name;
import model.PhoneNumber;
import view.CreateContract;
import view.CreateItem;
import view.CreateMemberView;
import view.DetailItem;
import view.DetailItem.DetailItemAction;
import view.DetailMember;
import view.DetailMember.DetailMemberAction;
import view.ListItems;
import view.ListItems.ListItemsAction;
import view.ListItemsToBorrow;
import view.ListMembers;
import view.ListMembersVerbose;
import view.ListMembersView;
import view.UpdateItem;
import view.UpdateMember;
import view.UserInput;

public class ListMembersController {

  private Scanner scanner;
  private LendingSystem ls;

    /* 
 private void listMembersVerbose() {
    ListMembersVerbose view = new ListMembersVerbose();
    ArrayList<Member> members = ls.getMembers();
    UserInput<ListMembersVerbose.ListMembersAction> userInput;

    do {
      ArrayList<Contract> contracts = new ArrayList<>();

      for (Member member : members) {

        List<Item> items = member.getItems();

        for (Item item : items) {
          contracts.addAll(item.getContracts());
        }
      }
      userInput = view.promptForMemberSelection(members, contracts, scanner);

      if (userInput.getAction() == ListMembersVerbose.ListMembersAction.BACK) {
        return;
      }

      Member selectedMember = members.get(userInput.getInteger() - 1);
      detailMember(selectedMember);
    } while (userInput.getAction() != ListMembersVerbose.ListMembersAction.BACK);
  }
*/

  protected void listMembers(ListMembersView view, LendingSystem ls, Scanner scanner) {

    this.scanner = scanner;
    this.ls = ls;

    ArrayList<Member> members = ls.getMembers();
    UserInput<ListMembersView.ListMembersAction> userInput;
    do {
      userInput = view.promptForMemberSelection(members, scanner);

      if (userInput.getAction() == ListMembersView.ListMembersAction.BACK) {
        return;
      }

      Member selectedMember = members.get(userInput.getInteger() - 1);
      detailMember(selectedMember);
    } while (userInput.getAction() != ListMembersView.ListMembersAction.BACK);
  }

  private void detailMember(Member member) {
    DetailMember view = new DetailMember(scanner);
    DetailMemberAction action;

    do {
      view.displayMemberDetails(member);
      UserInput<DetailMember.DetailMemberAction> userInput = view.getUserInput(scanner);

      action = userInput.getAction();

      switch (action) {
        case UPDATE_NAME:
          updateName(member);
          break;
        case UPDATE_EMAIL:
          updateEmail(member);
          break;
        case UPDATE_PHONE_NUMBER:
          updatePhoneNumber(member);
          break;
        case DELETE:
          deleteMember(member);
          break;
        case ADD_ITEM:
          addItemToMember(member);
          break;
        case LIST_ITEMS:
          listItems(member);
          break;
        case BORROW_ITEM:
          borrowItems(member);
          break;
        case BACK:
          return;
        case None:
          break;
        default:
          break;
      }
    } while (action != DetailMember.DetailMemberAction.BACK);
  }

  private void borrowItems(Member member) {
    ListItemsToBorrow view = new ListItemsToBorrow();
    ArrayList<Item> items = ls.getAllItems();
    Item item;
    UserInput<ListItemsToBorrow.ListItemsToBorrowAction> userInput;
    do {
      userInput = view.promptForItemSelection(items, scanner);

      if (userInput.getAction() == ListItemsToBorrow.ListItemsToBorrowAction.BACK) {
        return;
      }
      item = items.get(userInput.getInteger() - 1);

      displayItemDetails(member, item);

    } while (userInput.getAction() != ListItemsToBorrow.ListItemsToBorrowAction.BACK);

  }

  private void displayItemDetails(Member member, Item item) {
    ListItemsToBorrow view = new ListItemsToBorrow();

    UserInput<ListItemsToBorrow.ListItemsToBorrowAction> userInput;
    do {
      List<Contract> contracts = item.getContracts();
      view.displayItemDetails(item, contracts);
      userInput = view.promptForItemDetailSelection(scanner);

      switch (userInput.getAction()) {
        case BORROW_ITEM:
          createContract(member, item);
          break;
        case BACK:
          return;
        default:
          break;
      }

    } while (userInput.getAction() != ListItemsToBorrow.ListItemsToBorrowAction.BACK);
  }

  private void createContract(Member member, Item item) {
    CreateContract view = new CreateContract();
    view.showCurrentDay(ls.getCurrentDay());
    boolean acceptedDays = false;
    int startDay = 0;
    int endDay = 0;

    while (!acceptedDays) {
      startDay = view.promptForStartDay(scanner);
      endDay = view.promptForEndDay(scanner);
      if (startDay < ls.getCurrentDay()) {
        System.out.println("The start day cannot be set to a past day");
        continue;
      } else if (endDay < startDay) {
        System.out.println("The end day cannot be before the start day.");
        continue;
      }

      if (item.getContracts().size() == 0) {
        acceptedDays = true;
      } else {
        for (Contract contract : item.getContracts()) {
          for (int day = startDay; day <= endDay; day++) {
            if (contract.isActive(day)) {
              System.out.println("Sorry the item has already an active contract at "
                  + day
                  + " day. Try to choose another star/end days");
              break;
            }
            acceptedDays = true;
          }
        }
      }

    }
    Contract contract = new Contract(member, startDay, endDay, item);

    boolean isPaid = ls.makePaymentForContract(contract);

    if (isPaid) {
      ls.establishContract(contract);
    } else {
      System.out.println("Sorry! You don't have enough cridets to borrow it!");
    }
  }

  private void listItems(Member member) {
    ListItems view = new ListItems();

    UserInput<ListItems.ListItemsAction> userInput;
    do {
      view.displayItems(member);
      userInput = view.promptForItemSelection(member, scanner);

      if (userInput.getAction() == ListItemsAction.BACK) {
        return;
      }

      if (userInput.getInteger() > 0) { // If the user selected an item
        List<Item> items = member.getItems();
        Item item = items.get(userInput.getInteger() - 1);
        detailItem(item, member);
      }
    } while (userInput.getAction() != ListItemsAction.BACK);
  }

  private void detailItem(Item item, Member member) {
    DetailItem view = new DetailItem(scanner);
    DetailItemAction action;
    UserInput<DetailItemAction> userInput;
    do {
      view.displayitemDetails(item);
      userInput = view.getUserInput(scanner);
      action = userInput.getAction();

      switch (action) {
        case UPDATE_NAME:
          updateItemName(item);
          break;
        case UPDATE_DESCRIPTION:
          updateDescription(item);
          break;
        case UPDATE_CATEGORY:
          updateCategory(item);
          break;
        case UPDATE_PRICE:
          updatePrice(item);
          break;
        case DELETE:
          deleteItem(item);
          break;
        case None:
          break;
        default:
          break;
      }
    } while (action != DetailItemAction.BACK && action != DetailItemAction.DELETE);

  }

  private void deleteItem(Item item) {
    item.delete();
  }

  private void updatePrice(Item item) {
    UpdateItem view = new UpdateItem();
    view.updatePrice(item, scanner);

  }

  private void updateCategory(Item item) {
    UpdateItem view = new UpdateItem();
    view.updateCategory(item, scanner);

  }

  private void updateDescription(Item item) {
    UpdateItem view = new UpdateItem();
    view.updateShortDescription(item, scanner);
  }

  private void updateItemName(Item item) {
    UpdateItem view = new UpdateItem();
    view.updateName(item, scanner);
  }

  private void updateName(Member member) {
    UpdateMember view = new UpdateMember();
    view.updateName(member, scanner);
  }

  private void updateEmail(Member member) {
    UpdateMember view = new UpdateMember();
    view.updateEmail(member, scanner);
  }

  private void updatePhoneNumber(Member member) {
    UpdateMember view = new UpdateMember();
    view.updatePhoneNumber(member, scanner);
  }

  private void deleteMember(Member member) {
    ls.deleteMember(member);
  }

  private void addItemToMember(Member member) {
    CreateItem view = new CreateItem();
    String name = view.promptForItemName(scanner);
    String shortDescription = view.promptForItemShortDescription(scanner);
    String itemCategory = view.promptForItemCategory(scanner);
    int costPerDay = view.promptForItemCostPerDay(scanner);

    member.addItem(name, shortDescription, itemCategory, costPerDay, ls.getCurrentDay());
  }}
