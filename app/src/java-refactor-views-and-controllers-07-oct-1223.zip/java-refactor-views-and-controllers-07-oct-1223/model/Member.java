package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * class member.
 */
public class Member {
  private static final int startCridets = 100;
  private String idString;
  private Name name;
  private Email email;
  private PhoneNumber phoneNumber;
  private int credits;
  private int creationDay; // are we intressted with this variable
  private List<Item> items;
  private List<Contract> contracts;

  /**
   * Constructor.
   *
   * @param name  The name of the member
   * @param email The email of the member
   * @param phoneNumber The phone number of the member
   * @param currentDay The current day
   *
   */
  public Member(Name name, Email email, PhoneNumber phoneNumber, int currentDay) {
    this.name = name;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.credits = startCridets;
    this.creationDay = currentDay;
    this.items = new ArrayList<>();
    this.contracts = new ArrayList<>();
  }

  /**
   * Copy Constructor.
   *
   * @param member  The member to copy
   *
   */
  public Member(Member member) {
    this.name = member.name;
    this.email = member.email;
    this.phoneNumber = member.phoneNumber;
    this.credits = member.credits;
    this.creationDay = member.creationDay;
    this.items = member.items;
    this.contracts = member.contracts;
  }

  /**
   * Add item.
   *
   * @param title The item title
   * @param description The item description
   * @param category  The item category
   * @param costPerDay The item cost per day
   * @param creationDay  The item the day was added to the system
   */
  public void addItem(String title, String description, String category, int costPerDay, int creationDay) {
    Item newItem = new Item(this, title, description, category, costPerDay, creationDay);
    this.items.add(newItem);
    this.credits += 100;
  }

  public String getName() {
    return this.name.getName();
  }

  public String getPhoneNumber() {
    return this.phoneNumber.getPhoneNumber();
  }

  public String getEmail() {
    return this.email.getEmail();
  }

  public int getCredits() {
    return this.credits;
  }
  
  public int getCreationDay() {
    return this.creationDay;
  }
  
  public String getUserId() {
    return this.idString;
  }

  public void setUserId(String idString) {
    this.idString = idString;
  }

  public void setEmail(Email email) {
    this.email = email;
  }

  public void setName(Name name) {
    this.name = name;
  }

  public void setPhoneNumber(PhoneNumber phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public void deleteItem(Item item) {
    this.items.remove(item);
  }

  public List<Item> getItems() {
    return Collections.unmodifiableList(this.items);
  }

  public List<Contract> getContracts() {
    return Collections.unmodifiableList(this.contracts);
  }

  public void addContract(Contract contract) {
    this.contracts.add(contract);
  }
  
  @Override
  public String toString() {
    return "Name: " + name + ", Email: " + email + ", Phone number: " + phoneNumber;
  }

  public void removeCredits(int credits) {
    this.credits -= credits;
  }

  public void addCredits(int credits) {
    this.credits += credits;
  }

  public void deleteContract(Contract contract) {
    this.contracts.remove(contract);
  }
}
