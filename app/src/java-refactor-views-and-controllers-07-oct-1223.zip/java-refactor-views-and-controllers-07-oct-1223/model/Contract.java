package model;

/**
 * class contract.
 */
public class Contract {
  private Member borrower;
  private int startDay;
  private int endDay;
  private Item item;

  /**
   * Constructor.
   *
   * @param borrower
   *
   * @param startDay
   *
   * @param endDay
   *
   * @param item
   * 
   */
  public Contract(Member borrower, int startDay, int endDay, Item item) {
    this.borrower = new Member(borrower);
    this.startDay = startDay;
    this.endDay = endDay;
    this.item = new Item(item);
  }

  /**
   * Method return true if contract is active.
   *
   * @param day
   * 
   * @return
   * 
   */
  public boolean isActive(int day) {
    if (day >= startDay && day <= endDay) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * Calculate and return the cost.
   *
   * @return
   * 
   */
  public int getCost() {
    int cost;

    if (borrower.getItems().contains(item)) {
      cost = 0;
      return cost;
    } else {
      cost = item.getPrice() * (endDay - startDay);
      return cost;
    }
  }

  public int getStartDay() {
    return this.startDay;
  }

  public int getEndDay() {
    return this.endDay;
  }

  public Member getBorrower() {
    return new Member(this.borrower);
  }

  public Item getItem() {
    return new Item(this.item);
  }

  public Member getLender() {
    return this.item.getOwner();
  }
}
