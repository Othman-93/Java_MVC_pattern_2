package model;

/**
 * Name class.
 */
public class Name {
  private String name;

  /**
   * Constructor.
   *
   * @param name  The name string
   *
   * @throws IllegalArgumentException Name must contain at least one character
   */
  public Name(String name) {
    if (name.length() < 1) {
      throw new IllegalArgumentException("Name must contain at least one character.");
    }
    this.name = name;
  }

  public String getName() {
    return name;
  }

  @Override
  public String toString() {
    return name;
  }
}