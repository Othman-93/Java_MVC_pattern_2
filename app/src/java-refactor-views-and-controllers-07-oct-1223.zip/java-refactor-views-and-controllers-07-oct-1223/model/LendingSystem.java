package model;

import java.util.ArrayList;
import java.util.Random;

/**
 * Controller.
 */
public class LendingSystem {
  private ArrayList<Member> members;
  private DayCounter dayCounter;
  private Random random;

  /**
   * Constructor.
   */
  public LendingSystem() {
    members = new ArrayList<>();
    dayCounter = new DayCounter();
    random = new Random();
  }

  /**
   * Get total number of contracts.
   *
   * @return - The total number of contracts as int
   */
  public int getTotalNumberOfContracts() {
    ArrayList<Contract> contacts = new ArrayList<Contract>();

    for (Member member : members) {
      contacts.addAll(member.getContracts());
    }
    return contacts.size();
  }

  /**
   * Get total number of contracts.
   *
   * @return - The total number of active contracts as int
   */
  public int getTotalNumberOfActiveContracts() {
    ArrayList<Contract> contacts = new ArrayList<Contract>();

    for (Member member : members) {
      for (Contract contract : member.getContracts()) {
        if (contract.isActive(getCurrentDay())) {
          contacts.add(contract);
        }
      }
    }
    return contacts.size();
  }

  /**
   * Get total number of items.
   *
   * @return - The total number of items as int.
   */
  public int getTotalNumberOfItems() {
    return getAllItems().size();
  }

  /**
   * Get total number of members.
   *
   * @return The total number of members as int.
   */
  public int getTotalNumberOfMembers() {
    return members.size();
  }

  /**
   * Get current day.
   *
   * @return The current day as int.
   */
  public int getCurrentDay() {
    return dayCounter.getCurrentDay();
  }

  /**
   * Advance day.
   */
  public void advanceDay() {
    dayCounter.advanceDay();
  }

  /**
   * This method used insid Admin where we loop into the members and for each
   * member we show only his active items
   * assuming that we only establish contracts with availble item, even for future
   * contracts cases.
   * in Admin
   *
   * @return items
   *
   */
  public ArrayList<Item> getAllItems() {
    ArrayList<Item> items = new ArrayList<Item>();

    for (Member member : members) {
      items.addAll(member.getItems());
    }
    return items;
  }

  /**
   * Add a new member.
   *
   * @param member
   *
   */
  public void addMember(Member member) {
    SystemValidationService valditionService = new SystemValidationService();

    if (valditionService.validateMember(member, members)) {
      member.setUserId(generateId(members));
      this.members.add(member);
    } else {
      throw new IllegalArgumentException("Could not create member: Email and Phone must be Unique.");
    }
  }

  private String generateId(ArrayList<Member> memberList) {
    final int idLength = 6;
    final char[] alphaNumric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
    boolean isUnique = true;
    StringBuffer buf = new StringBuffer();
    String id = " ";
    do {

      for (int i = 0; i < idLength; i++) {
        int randomIndex = random.nextInt(alphaNumric.length);
        buf.append(alphaNumric[randomIndex]);
      }
      id = buf.toString();
      for (Member member : memberList) {
        if (member.getUserId().equals(id)) {
          isUnique = false;
          break;
        }
      }

    } while (isUnique == false);

    return id;
  }
  

  public ArrayList<Member> getMembers() {
    return new ArrayList<>(members);
  }

  public void deleteMember(Member member) {
    members.remove(member);
  }

  /**
   * get contracts from own items.
   *
   * @param member
   *
   * @return
   *
   */
  public ArrayList<Contract> getLendedContractsForMember(Member member) {

    ArrayList<Contract> contractsForMember = new ArrayList<>();

    for (Item item : member.getItems()) {
      for (Contract contract : item.getContracts()) {
        contractsForMember.add(contract);
      }
    }

    return contractsForMember;
  }

  /**
   * Make payment for contract.
   *
   * @param contract The contract
   * @return The sucess of the payment as boolean
   */
  public boolean makePaymentForContract(Contract contract) {

    Member borrower = contract.getBorrower();
    Member lender = contract.getLender();

    if (borrower.getCredits() >= contract.getCost()) {

      borrower.removeCredits(contract.getCost());
      lender.addCredits(contract.getCost());

      return true;
    }
    return false;
  }

  /**
   * Establish contract.
   *
   * @param contract The contract to establish in the system.
   */
  public void establishContract(Contract contract) {
    contract.getBorrower().addContract(contract);
    contract.getItem().addContract(contract);
  }
}