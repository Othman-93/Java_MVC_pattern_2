package model;

/**
 * PhoneNumber class.
 */
public class PhoneNumber {
  private String phoneNumber;

  /**
   * Constructor.
   *
   * @param phoneNumber The phone number string
   *
   * @throws IllegalArgumentException Phone number must contain at least one character
   */
  public PhoneNumber(String phoneNumber) {
    if (phoneNumber.length() < 1) {
      throw new IllegalArgumentException("Phone number must contain at least one character.");
    }
    this.phoneNumber = phoneNumber;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  @Override
  public String toString() {
    return phoneNumber;
  }
}
