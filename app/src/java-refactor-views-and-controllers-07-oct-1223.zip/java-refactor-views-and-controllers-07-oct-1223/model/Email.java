package model;

/**
 * Contract class.
 */
public class Email {
  private String email;

  /**
  * Email constructor.
  */
  public Email(String email) {
    if (!email.contains("@")) {
      throw new IllegalArgumentException("Email must contain at least one '@'");
    }
    if (!email.contains(".")) {
      throw new IllegalArgumentException("Email must contain at least one '.'");
    }
    this.email = email;
  }

  public String getEmail() {
    return email;
  }

  @Override
  public String toString() {
    return email;
  }

}
