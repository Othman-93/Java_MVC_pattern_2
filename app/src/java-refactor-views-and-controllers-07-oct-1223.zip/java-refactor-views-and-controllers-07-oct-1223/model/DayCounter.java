package model;

/**
* DayCounter class.
*/
public class DayCounter {
  private int currentDay;

  public DayCounter() {
    currentDay = 0;
  }

  public int getCurrentDay() {
    return currentDay;
  }

  public void advanceDay() {
    currentDay += 1;
  }
}
