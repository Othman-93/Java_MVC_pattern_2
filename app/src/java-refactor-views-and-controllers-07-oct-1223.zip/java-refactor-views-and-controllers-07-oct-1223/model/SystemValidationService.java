package model;

import java.util.ArrayList;

/**
* SystemValidationService class.
*/
public class SystemValidationService {

  /**
  * Validate member.
  *
  * @param newMember -  The member to validate if email and phone are unique
  * @param memberList - The member list to compare against
  *
  * @return - boolean to indicate if the user passed validtion successfully
  */
  public boolean validateMember(Member newMember, ArrayList<Member> memberList) {
    for (Member member : memberList) {
      if (member.getPhoneNumber().equals(newMember.getPhoneNumber())) {
        return false;
      }

      if (member.getEmail().equals(newMember.getEmail())) {
        return false;
      }
    }
    return true;
  }
}
