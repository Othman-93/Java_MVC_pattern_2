package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * class item.
 */
public class Item {
  private Member owner;
  private String name;
  private String shortDescription;
  private int price;
  private String category;
  private int creationDay;
  private ArrayList<Contract> contracts;

  /**
   * Constructor.
   *
   * @param owner The owner of the item
   * @param name  The name of the item
   * @param shortDecription The short description of the item
   * @param category  The category of the item
   * @param price The price of the item
   * @param creationDay The current day, will be set as the creationDay of the item
   *
   */
  public Item(Member owner, String name, String shortDecription, String category, int price, int creationDay) {
    this.owner = new Member(owner);
    this.name = name;
    this.shortDescription = shortDecription;
    this.category = category;
    this.price = price;
    this.creationDay = creationDay;
    this.contracts = new ArrayList<Contract>();
  }
  
  /**
   * Copy Constructor.
   *
   * @param item  The item to copy
   *
   */
  public Item(Item item) {
    this.owner = item.owner;
    this.name = item.name;
    this.shortDescription = item.shortDescription;
    this.category = item.category;
    this.price = item.price;
    this.creationDay = item.creationDay;
    this.contracts = item.contracts;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getShortDescription() {
    return shortDescription;
  }

  public void setShortDescription(String shortDescription) {
    this.shortDescription = shortDescription;
  }

  public int getPrice() {
    return price;
  }

  public void setPrice(int price) {
    this.price = price;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public int getCreationDay() {
    return creationDay;
  }

  public void setCreationDay(int creationDay) {
    this.creationDay = creationDay;
  }

  public List<Contract> getContracts() {
    return Collections.unmodifiableList(this.contracts);
  } 

  public void addContract(Contract contract) {
    this.contracts.add(contract);
  }

  protected Member getOwner() {
    return owner;
  }

  /**
   * Delete the item and it's related contracts.
   */
  public void delete() {
    for (Contract contract : contracts) {
      Member borrower = contract.getBorrower();
      borrower.deleteContract(contract);
    }

    this.contracts = new ArrayList<>(contracts);

    this.owner.deleteItem(this);
  }
}
