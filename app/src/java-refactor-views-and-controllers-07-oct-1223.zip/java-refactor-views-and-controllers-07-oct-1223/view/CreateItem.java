package view;

import java.util.Scanner;

/**
 * CreateItem class.
 */
public class CreateItem {

  /**
   * Constructor.
   */
  public CreateItem() {

  }

  /**
   * Prompt for item name.
   *
   * @return  The name as a string
   */
  public String promptForItemName(Scanner scanner) {
    System.out.println("Enter the name of the item (or 0 to go back)");
    return scanner.nextLine();
  }

  /**
   * Prompt for item short description.
   *
   * @return  The item short description as a string
   */
  public String promptForItemShortDescription(Scanner scanner) {
    System.out.println("Enter the short description of the item (or 0 to go back)");
    return scanner.nextLine();
  }

  /**
   * Prompt for item category.
   *
   * @return  The item category as a string
   */
  public String promptForItemCategory(Scanner scanner) {
    System.out.println("Enter the category of the item (or 0 to go back)");
    return scanner.nextLine();
  }

  /**
   * Prompt for item cost per day.
   *
   * @return The item cost as an int
   */
  public int promptForItemCostPerDay(Scanner scanner) {
    System.out.println("Enter the cost per day of the item (or 0 to go back)");
    int costPerDay = scanner.nextInt();
    scanner.nextLine();

    return costPerDay;
  }
}
