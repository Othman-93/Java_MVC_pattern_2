package view;

import java.util.List;
import java.util.Scanner;
import model.Item;
import model.Member;

/**
 * ListItems class.
 */
public class ListItems {

  /**
   * Enum ListItemsAction.
   */
  public enum ListItemsAction {
    BACK
  }

  /**
   * Constructor.
   */
  public ListItems() {
  }

  /**
  * Get user input.
  *
  * @return  The List Items Action selected by the user
  */
  public UserInput<ListItemsAction> promptForItemSelection(Member member, Scanner scanner) {
    int choice = scanner.nextInt();
    scanner.nextLine();

    if (choice == 0) {
      return new UserInput<ListItemsAction>(ListItemsAction.BACK);
    }

    while (choice < 0 || choice > member.getItems().size()) {
      System.out.println("");
      System.out.println("Incorrect selection. Please try again:");
      choice = scanner.nextInt();
      scanner.nextLine();
    }
    return new UserInput<>(choice);
  }

  /**
   * Display items.
   *
   * @param member  The member to display the items of
   */
  public void displayItems(Member member) {
    List<Item> items = member.getItems();
    System.out.println("");

    if (member.getItems().size() == 0) {
      System.out.println(member.getName() + " Has no items! \n");
    } else {
      int counter = 1;
      System.out.println(member.getName() + " Has the following items: ");
      for (Item item : items) {
        System.out.println(counter + "). " + item.getName());
        counter++;
      }
    }

    System.out.println("0) Back");
  }
}
