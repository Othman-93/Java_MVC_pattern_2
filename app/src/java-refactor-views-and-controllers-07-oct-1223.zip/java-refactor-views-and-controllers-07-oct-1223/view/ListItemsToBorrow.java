package view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import model.Contract;
import model.Item;

/**
* List items to borrow.
*/
public class ListItemsToBorrow {

  /**
   * Enum List items to borrow action.
   */
  public enum ListItemsToBorrowAction {
    BORROW_ITEM,
    BACK,
    None
  }

  /**
   * Constructor.
   */
  public ListItemsToBorrow() {

  }

  /**
   * Get user input.
   *
   * @return  List items to borrow action selected by the user
   */
  public UserInput<ListItemsToBorrowAction> promptForItemSelection(ArrayList<Item> items, Scanner scanner) {
    displayItems(items);
    int choice = scanner.nextInt();
    scanner.nextLine();

    if (choice == 0) {
      return new UserInput<ListItemsToBorrowAction>(ListItemsToBorrowAction.BACK);
    }

    while (choice < 0 || choice > items.size()) {
      System.out.println("");
      System.out.println("Incorrect selection. Please try again:");
      choice = scanner.nextInt();
      scanner.nextLine();
    }
    return new UserInput<>(choice);
  }

  /**
   * Get user input.
   *
   * @return  The list items to borrow action selected by the user
   */
  public UserInput<ListItemsToBorrowAction> promptForItemDetailSelection(Scanner scanner) {
    ListItemsToBorrowAction choice;
    do {
      choice = toListItemsToBorrowAction(scanner.nextInt());
      scanner.nextLine();
    } while (choice == ListItemsToBorrowAction.None);

    return new UserInput<>(choice);
  }

  /**
   * Display items.
   *
   * @param items The items to display
   */
  private void displayItems(ArrayList<Item> items) {
    int counter = 1;
    System.out.println("");
    System.out.println("The following items are available to borrow: ");
    for (Item item : items) {
      System.out.println(counter + "). " + item.getName());
      counter++;
    }

    System.out.println("0) Back");
  }

  /**
   * Display item details.
   *
   * @param item  The item to display.
   * @param contracts The contracts to display.
   */
  public void displayItemDetails(Item item, List<Contract> contracts) {
    System.out.println("");
    System.out.println("Item Details");
    System.out.println("----------------");
    System.out.println("Name: " + item.getName());
    System.out.println("Short desription: " + item.getShortDescription());
    System.out.println("Price per day: " + item.getPrice());
    System.out.println("----------------");
    System.out.println("Availability:");
    if (contracts.size() == 0) {
      System.out.println("Available for borrowing!");
    } else {
      for (Contract contract : contracts) {
        System.out.println("Borrowed day: " + contract.getStartDay() + "-" + contract.getEndDay());
      }
    }

    System.out.println("1) Borrow item");
    System.out.println("0) Back");
  }

  private ListItemsToBorrowAction toListItemsToBorrowAction(int input) {

    switch (input) {
      case 0:
        return ListItemsToBorrowAction.BACK;
      case 1:
        return ListItemsToBorrowAction.BORROW_ITEM;
      default:
        return ListItemsToBorrowAction.None;
    }
  }
}
