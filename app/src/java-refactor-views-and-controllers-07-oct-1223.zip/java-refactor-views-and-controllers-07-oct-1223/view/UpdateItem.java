package view;

import java.util.Scanner;
import model.Item;

/**
 * UpdateItem class.
 */
public class UpdateItem {

  /**
   * Constructor.
   */
  public UpdateItem() {

  }

  /**
   * Update name.
   *
   * @param item  The item to update the name of
   */
  public void updateName(Item item, Scanner scanner) {
    System.out.print("Enter a new Name: ");
    String input = scanner.nextLine();
    item.setName(input);
  }

  /**
   * Update category.
   *
   * @param item  The item to update the category of
   */
  public void updateCategory(Item item, Scanner scanner) {
    System.out.print("Enter a new Category: ");
    String input = scanner.nextLine();
    item.setCategory(input);
  }

  /**
   * Update short description.
   *
   * @param item  The item to update the short description of
   */
  public void updateShortDescription(Item item, Scanner scanner) {
    System.out.print("Enter a new Description: ");
    String input = scanner.nextLine();
    item.setShortDescription(input);
  }

  /**
   * Update price.
   *
   * @param item  The item to update the price of
   */
  public void updatePrice(Item item, Scanner scanner) {
    System.out.print("Enter a new Price: ");
    int input = scanner.nextInt();
    item.setPrice(input);
  }
}
