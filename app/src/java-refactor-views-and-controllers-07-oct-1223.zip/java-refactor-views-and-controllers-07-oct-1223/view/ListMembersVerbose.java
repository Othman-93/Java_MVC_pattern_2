package view;

import java.util.ArrayList;
import java.util.Scanner;
import model.Contract;
import model.Item;
import model.Member;

/**
 * ListMembersVerbose class.
 */
public class ListMembersVerbose {

  /**
   * Enum ListMembersAction.
   */
  public enum ListMembersAction {
    BACK
  }

  /**
   * Constructor.
   */
  public ListMembersVerbose() {

  }

  /**
  * Get user input.
  *
  * @return  The List Members Action selected by the user
  */
  public UserInput<ListMembersAction> promptForMemberSelection(ArrayList<Member> members,
      ArrayList<Contract> contracts, Scanner scanner) {

    displayMembers(members, contracts);
    int choice = scanner.nextInt();
    scanner.nextLine();

    if (choice == 0) {
      return new UserInput<ListMembersAction>(ListMembersAction.BACK);
    }

    while (choice < 0 || choice > members.size()) {
      System.out.println("");
      System.out.println("Incorrect selection. Please try again:");
      choice = scanner.nextInt();
      scanner.nextLine();
    }
    return new UserInput<>(choice);
  }

  private void displayMembers(ArrayList<Member> members, ArrayList<Contract> contracts) {
    System.out.println("");
    System.out.println("List members (" + members.size() + ")");
    System.out.println("----------------");
    if (members.size() == 0) {
      System.out.println("There are no members in the system.");
    } else {
      int index = 1;
      for (Member member : members) {
        System.out.println(index + ") " + member.toString());
        int itemIndex = 1;
        for (Item item : member.getItems()) {
          System.out.println("--- Item #" + itemIndex + ". ---");
          System.out.println("Name: " + item.getName());
          boolean isAvailable = true;
          for (Contract contract : contracts) {
            if (contract.getLender().getUserId().equals(member.getUserId()) && item.equals(contract.getItem())) {
              isAvailable = false;
              System.out.println("Borrowed by: " + contract.getBorrower().getName());
              System.out.println("From day " + contract.getStartDay() + " to day " + contract.getEndDay() + ".");
              itemIndex++;
            }
          }
          if (isAvailable) {
            System.out.println("Contract: None");
          }
          System.out.println("");
        }
        index++;
      }
    }
    System.out.println("0) Back");
  }
}
