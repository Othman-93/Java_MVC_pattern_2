package view;

import java.util.Optional;
import java.util.Scanner;
import java.util.function.Function;
import model.Email;
import model.Member;
import model.Name;
import model.PhoneNumber;

/**
 * Create member class.
 */
public class CreateMemberView {

  /**
   * Create a member.
   *
   * @param day The current day
   * @return  An optional instance, which may contain a member
   */
  public Optional<Member> createMember(int day, Scanner scanner) {
    Optional<Name> name = prompt("Enter a name (or nothing to abort)", Name::new, scanner);
    if (!name.isPresent()) {
      return Optional.empty();
    }

    Optional<Email> email = prompt("Enter an email (or nothing to abort)", Email::new, scanner);
    if (!email.isPresent()) {
      return Optional.empty();
    }

    Optional<PhoneNumber> phoneNumber = prompt("Enter a phone number (or nothing to abort)", PhoneNumber::new, scanner);
    if (!phoneNumber.isPresent()) {
      return Optional.empty();
    }

    return Optional.of(new Member(name.get(), email.get(), phoneNumber.get(), day));
  }

  private <T> Optional<T> prompt(String message, Function<String, T> function, Scanner scanner) {
    System.out.println("");
    System.out.println(message);
    while (true) {
      String input = scanner.nextLine();

      if (input.equals("")) {
        return Optional.empty();
      }

      try {
        return Optional.of(function.apply(input));
      } catch (IllegalArgumentException e) {
        System.out.println("");
        System.out.println(e.getMessage() + ", please try again.");
      }
    }
  }

  public void printError(String message) {
    System.out.println(message);
  }

public void printAbortMessage() {
        System.out.println("Aborted.");
}
}

