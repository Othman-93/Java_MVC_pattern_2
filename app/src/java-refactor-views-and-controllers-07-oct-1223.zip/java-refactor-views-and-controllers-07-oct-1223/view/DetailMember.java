package view;

import java.util.Scanner;
import model.Member;

/**
 * DetailMember class.
 */
public class DetailMember {

  /**
   * Enum Detail Member Action.
   */
  public enum DetailMemberAction {
    BACK,
    UPDATE_NAME,
    UPDATE_EMAIL,
    UPDATE_PHONE_NUMBER,
    DELETE,
    ADD_ITEM,
    LIST_ITEMS,
    BORROW_ITEM,
    None
  }

  /**
   * Constructor.
   */
  public DetailMember(Scanner scanner) {

  }

  /**
   * Display member details.
   *
   * @param member The member to display details for.
   */
  public void displayMemberDetails(Member member) {
    System.out.println("");
    System.out.println("Member Details");
    System.out.println("----------------");
    System.out.println("Name: " + member.getName());
    System.out.println("Email: " + member.getEmail());
    System.out.println("Phone number: " + member.getPhoneNumber());
    System.out.println("Member ID: "  + member.getUserId());
    System.out.println("Creation date:"   + member.getCreationDay());
    
    System.out.println("Credits: " + member.getCredits());
    System.out.println("Member ID: " + member.getUserId());

    System.out.println("Number of owned items: " + member.getItems().size());
    
    System.out.println("");
    System.out.println("1. Update name");
    System.out.println("2. Update email");
    System.out.println("3. Update phone number");
    System.out.println("4. Delete member");
    System.out.println("5. Add owned item");
    System.out.println("6. List owned items");
    System.out.println("7. Borrow an item");
    System.out.println("0) Back");
  }

  /**
   * Get user input.
   *
   * @return The Main menu action selected by the user
   */
  public UserInput<DetailMemberAction> getUserInput(Scanner scanner) {
    String input = scanner.nextLine();
    DetailMemberAction action = toDetailMemberAction(input);
    return new UserInput<DetailMemberAction>(action);
  }

  private DetailMemberAction toDetailMemberAction(String input) {
    if (input.length() == 0) {
      return DetailMemberAction.None;
    }
    switch (input.charAt(0)) {
      case '0':
        return DetailMemberAction.BACK;
      case '1':
        return DetailMemberAction.UPDATE_NAME;
      case '2':
        return DetailMemberAction.UPDATE_EMAIL;
      case '3':
        return DetailMemberAction.UPDATE_PHONE_NUMBER;
      case '4':
        return DetailMemberAction.DELETE;
      case '5':
        return DetailMemberAction.ADD_ITEM;
      case '6':
        return DetailMemberAction.LIST_ITEMS;
      case '7':
        return DetailMemberAction.BORROW_ITEM;
      default:
        return DetailMemberAction.None;
    }
  }
}
