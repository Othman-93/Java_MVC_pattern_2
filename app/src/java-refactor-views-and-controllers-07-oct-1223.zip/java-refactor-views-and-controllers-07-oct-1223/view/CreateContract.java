package view;

import java.util.Scanner;

/**
 * Create contract.
 */
public class CreateContract {

  /**
   * Constructor.
   */
  public CreateContract() {

  }

  /**
   * Show current day.
   *
   * @param currentDay  The current day as int
   */
  public void showCurrentDay(int currentDay) {
    System.out.println("Today is day: " + currentDay);
  }

  /**
   * Prompt for start day.
   *
   * @return  The start day as int.
   */
  public int promptForStartDay(Scanner scanner) {
    System.out.println("Enter the start day:");
    int choice = scanner.nextInt();
    scanner.nextLine();
    return choice;
  }

  /**
   * Prompt for end day.
   *
   * @return  The end day as int.
   */
  public int promptForEndDay(Scanner scanner) {
    System.out.println("Enter the end day:");
    int choice = scanner.nextInt();
    scanner.nextLine();
    return choice;
  }
}
