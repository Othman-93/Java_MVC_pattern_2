package view;

import java.util.ArrayList;
import java.util.Scanner;
import model.Member;

/**
* ListMembers class.
*/
public class ListMembersView {

  /**
  * Enum ListMembersAction.
  */
  public enum ListMembersAction {
    BACK
  }

  /**
  * Constructor.
  */
  public ListMembersView() {

  }

  /**
  * Get user input.
  *
  * @return  The List Members Action selected by the user
  */
  public UserInput<ListMembersAction> promptForMemberSelection(ArrayList<Member> members, Scanner scanner) {
    displayMembers(members);
    int choice = scanner.nextInt();
    scanner.nextLine();

    if (choice == 0) {
      return new UserInput<ListMembersAction>(ListMembersAction.BACK);
    }

    while (choice < 0 || choice > members.size()) {
      System.out.println("");
      System.out.println("Incorrect selection. Please try again:");
      choice = scanner.nextInt();
      scanner.nextLine();
    }
    return new UserInput<>(choice);
  }

  private void displayMembers(ArrayList<Member> members) {
    System.out.println("");
    System.out.println("List members (" + members.size() + ")");
    System.out.println("----------------");

    if (members.size() == 0) {
      System.out.println("There are no members in the system.");
    } else {
      int index = 1;
      for (Member member : members) {
        System.out.println(index + ") " + member.toString());
        index++;
      }
    }
    System.out.println("0) Back");
  }
}
