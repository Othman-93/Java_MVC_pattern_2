package view;

import java.util.Scanner;

/**
 * MainMenu class.
 */
public class MainMenuView {

  private static final String INVALID_INPUT_MESSAGE = "Invalid input. Please try again.";
  public static final String MainMenu = null;

  /**
   * Enum MainMenuAction.
   */
  public static enum Action {
    EXIT,
    CREATE_MEMBER,
    LIST_MEMBERS,
    LIST_MEMBERS_VERBOSE,
    ADVANCE_DAY,
    None
  }

  /**
   * Display menu.
   */
  public void displayMenu(int currentDay) {
    System.out.println("");
    System.out.println("Main menu (Day " + currentDay + ")");
    System.out.println("----------------");
    System.out.println("1) Create member");
    System.out.println("2) List members");
    System.out.println("3) List members (Verbose)");
    System.out.println("4) Advance Day");
    System.out.println("0) Exit");
  }

  /**
   * Display system info.
   *
   * @param contracts - The number of contracts in the system
   * @param activeContracts - The number of active contracts in the system
   * @param numberOfItems - The number of items in the system
   * @param numberOfMembers - The number of members in the system
   */
  public void displaySysteminfo(int memberCount, int intemCount, int contractCount, int activeCountractCount) {
    System.out.println("");
    System.out.println("System info: ");
    System.out.println(memberCount + " members, " + intemCount + " items.");
    System.out.println(contractCount + " contracts, " + activeCountractCount + " active contracts.");
  }

  /**
   * Get user input.
   *
   * @return  The Main menu action selected by the user
   */
  public Action getUserAction(Scanner scanner) {
    String input = scanner.nextLine();
    Action action = toAction(input);
    
    while (action == Action.None) {
      System.out.println(INVALID_INPUT_MESSAGE);
      input = scanner.nextLine();
      action = toAction(input);
    }
    return action;
  }

  private Action toAction(String input) {
    if (input.length() == 0) {
      return Action.None;
    }

    switch (input.charAt(0)) {
      case '0':
        return Action.EXIT;
      case '1':
        return Action.CREATE_MEMBER;
      case '2':
        return Action.LIST_MEMBERS;
      case '3':
        return Action.LIST_MEMBERS_VERBOSE;
      case '4':
        return Action.ADVANCE_DAY;
      default:
        return Action.None;
    }
  }
}
