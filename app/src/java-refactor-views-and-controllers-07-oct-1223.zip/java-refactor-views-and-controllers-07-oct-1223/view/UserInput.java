package view;

/**
* UserInput class.
*/
public class UserInput<T> {
  private T action;
  private String string;
  private int integer;

  /**
  * Constructor for Action.
  *
  * @param action  The action
  */
  public UserInput(T action) {
    this(action, null, 0);
  }

  /**
  * Constructor for String.
  *
  * @param string  The string
  */
  public UserInput(String string) {
    this(null, string, 0);
  }

  /**
  * Constructor for int.
  *
  * @param integer The int
  */
  public UserInput(int integer) {
    this(null, null, integer);
  }

  private UserInput(T action, String string, int integer) {
    this.action = action;
    this.string = string;
    this.integer = integer;
  }

  /**
  * Get action.
  *
  * @return The action
  */
  public T getAction() {
    return action;
  }

  /**
  * Get string.
  *
  * @return  The string
  */
  public String getString() {
    return string;
  }

  /**
  * Get integer.
  *
  * @return The integer
  */
  public int getInteger() {
    return integer;
  }
}