package view;

import java.util.Scanner;
import java.util.function.Function;
import model.Email;
import model.Member;
import model.Name;
import model.PhoneNumber;

/**
 * Update member.
 */
public class UpdateMember {

  private static final String exit = "0";

  /**
   * Constructor.
   */
  public UpdateMember() {

  }

  /**
   * Update name.
   *
   * @param member  The member to update the name of
   * @return  The updated member
   */
  public Member updateName(Member member, Scanner scanner) {
    Name name = prompt("Enter a new name (or 0 to go back)", Name::new, scanner);
    if (name == null) {
      return null;
    }

    member.setName(name);
    return member;
  }

  /**
   * Update email.
   *
   * @param member - The member to update the email of.
   * @return  The updayed member.
   */
  public Member updateEmail(Member member, Scanner scanner) {
    Email email = prompt("Enter a new email (or 0 to go back)", Email::new, scanner);
    if (email == null) {
      return null;
    }

    member.setEmail(email);
    return member;
  }

  /**
   * Update phone number.
   *
   * @param member  The member to update the phone number of
   * @return  The updated member
   */
  public Member updatePhoneNumber(Member member, Scanner scanner) {
    PhoneNumber phoneNumber = prompt("Enter a new phone number (or 0 to go back)", PhoneNumber::new, scanner);
    if (phoneNumber == null) {
      return null;
    }

    member.setPhoneNumber(phoneNumber);
    return member;
  }

  private <T> T prompt(String message, Function<String, T> function, Scanner scanner) {
    System.out.println("");
    System.out.println(message);
    while (true) {
      String input = scanner.nextLine();

      if (input.equals(exit)) {
        return null;
      }

      try {
        return function.apply(input);
      } catch (IllegalArgumentException e) {
        System.out.println("");
        System.out.println(e.getMessage() + ", please try again.");
      }
    }
  }
}
