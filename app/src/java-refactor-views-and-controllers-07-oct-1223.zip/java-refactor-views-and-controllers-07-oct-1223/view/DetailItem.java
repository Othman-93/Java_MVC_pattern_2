package view;

import java.util.Scanner;
import model.Item;

/**
 * DetailItem class.
 */
public class DetailItem {

  /**
   * Enaum DetailItemAction.
   */
  public enum DetailItemAction {
    BACK,
    UPDATE_NAME,
    UPDATE_DESCRIPTION,
    UPDATE_CATEGORY,
    UPDATE_PRICE,
    DELETE,
    None
  }

  /**
   * Constructor.
   */
  public DetailItem(Scanner scanner) {

  }

  /**
   * Display item details.
   *
   * @param item  The item to display the details of
   */
  public void displayitemDetails(Item item) {
    System.out.println("");
    System.out.println("Item Details");
    System.out.println("----------------");
    System.out.println("Name: " + item.getName());
    System.out.println("Description: " + item.getShortDescription());
    System.out.println("Category: " + item.getCategory());
    System.out.println("Creation day: " + item.getCreationDay());
    System.out.println("");
    System.out.println("1. Update name");
    System.out.println("2. Update Description");
    System.out.println("3. Update Category");
    System.out.println("4. Update Price");
    System.out.println("5. Delete item");
    System.out.println("6. Get Owner name"); // to check map

    System.out.println("0) Back");
  }

  /**
  * Get user input.
  *
  * @return  The Detail Item Action selected by the user
  */
  public UserInput<DetailItemAction> getUserInput(Scanner scanner) {
    String input = scanner.nextLine();
    DetailItemAction action = toDetailItemAction(input);
    return new UserInput<DetailItemAction>(action);
  }

  private DetailItemAction toDetailItemAction(String input) {

    if (input.length() == 0) {
      return DetailItemAction.None;
    }
    switch (input.charAt(0)) {
      case '0':
        return DetailItemAction.BACK;
      case '1':
        return DetailItemAction.UPDATE_NAME;
      case '2':
        return DetailItemAction.UPDATE_DESCRIPTION;
      case '3':
        return DetailItemAction.UPDATE_CATEGORY;
      case '4':
        return DetailItemAction.UPDATE_PRICE;
      case '5':
        return DetailItemAction.DELETE;
      default:
        return DetailItemAction.None;
    }
  }
}
